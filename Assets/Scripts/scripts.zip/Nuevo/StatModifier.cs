
public class StatModifier
{
    public readonly float Value;

    public StatModifier(float value)
    {
        Value = value;
    }
}
